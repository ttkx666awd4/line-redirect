const express = require("express");
const app = express();
const port = process.env.PORT || 3000;

// LINE 客服清單
const lineLinks = [
  "https://page.line.me/605qnkyc",
  "https://page.line.me/431msctn",
  "https://page.line.me/690lcwsn",
  "https://page.line.me/359rofxa"
];

// IP mapped storage
const ipMap = new Map();

app.get("/", (req, res) => {
  res.send("LINE 輪詢伺服器啟動成功 ✅");
});

app.get("/go", (req, res) => {
  const ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  if (ipMap.has(ip)) {
    return res.redirect(302, ipMap.get(ip));
  } else {
    const selected = lineLinks[Math.floor(Math.random() * lineLinks.length)];
    ipMap.set(ip, selected);
    return res.redirect(302, selected);
  }
});

app.listen(port, () => {
  console.log(`LINE router server running on port ${port}`);
});